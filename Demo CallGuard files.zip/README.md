# CallGuard Demo - Tradie Connect AI

A live interactive demo of CallGuard, the AI receptionist for plumbing businesses.

## What's Included

- Interactive call capture demo
- 3 scenarios (Routine, Emergency, See More)
- Mobile-optimized design
- Branded with Tradie Connect AI colors

## Deploy to Vercel (Easiest)

### Step 1: Create a GitHub Account (if you don't have one)
Visit https://github.com/signup and create a free account.

### Step 2: Create a New Repository
1. Go to https://github.com/new
2. Name it: `callguard-demo`
3. Click "Create repository"

### Step 3: Upload Your Files
In your new repository:
1. Click "Add file" → "Upload files"
2. Drag and drop these files:
   - `index.html`
   - `package.json`
   - `vercel.json`
   - `README.md` (this file)
3. Click "Commit changes"

### Step 4: Deploy to Vercel
1. Go to https://vercel.com
2. Click "Sign Up" and choose "GitHub"
3. Authorize Vercel to access GitHub
4. Click "Add New..." → "Project"
5. Select your `callguard-demo` repository
6. Click "Deploy"

**That's it!** Vercel will give you a URL like:
```
https://callguard-demo.vercel.app
```

### Step 5: Share Your Demo
- Send the link to prospects
- Show it on your phone
- Embed it on your website

## Customization

Want to change anything? Edit `index.html`:

- **Email address:** Find `jeanine@tradieconnectai.com.au` and replace with your email
- **Phone number:** Update contact details
- **Scenarios:** Modify the conversation text in the `scenarios` object
- **Colors:** Change `#1B3A6B` (navy) and `#E8750A` (orange) to your brand colors

## Local Testing (Optional)

Run locally before deploying:
```bash
# Using Python (built-in on Mac/Linux)
python3 -m http.server 3000

# Then visit http://localhost:3000
```

## Troubleshooting

**Demo not showing?**
- Wait 1-2 minutes for Vercel to finish deploying
- Refresh the page (Ctrl+Shift+R or Cmd+Shift+R)
- Clear your browser cache

**Want to update it?**
- Edit files in your GitHub repository
- Vercel auto-redeploys when you commit changes

## Next Steps

Once you're showing prospects this demo:
1. Track how many click through
2. Collect feedback ("What features would help most?")
3. Use that to build the production version in Closebot or Botpress
4. Upsell Tier 2 bots (FlowMaster, LeakAlert, PipelineIQ)

---

Built with ❤️ for Tradie Connect AI
